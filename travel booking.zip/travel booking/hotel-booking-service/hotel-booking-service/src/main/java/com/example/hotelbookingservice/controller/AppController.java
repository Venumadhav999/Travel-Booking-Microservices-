package com.example.hotelbookingservice.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.hotelbookingservice.entity.Hotels;
import com.example.hotelbookingservice.response.ObjectResponse;
import com.example.hotelbookingservice.service.HotelService;

@RestController
@RequestMapping("/search")
public class AppController {

   
    @Autowired
    private HotelService hotelService;

    @GetMapping("/find-hotels/{hotelName}/{checkinDate}/{checkoutDate}") 
    public ResponseEntity<ObjectResponse> findHotels(@PathVariable String hotelName, 
                                                     @PathVariable String checkinDate, 
                                                     @PathVariable String checkoutDate) {
        ObjectResponse resp = new ObjectResponse();
        try {
            List<Hotels> hotels = hotelService.findByHotelNameAndRooms(hotelName, checkinDate, checkoutDate);
            resp.setResponseData(hotels);
            resp.setStatusCode(HttpStatus.OK);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred on the server");
            resp.setMessageType("ERROR");
            ex.printStackTrace();
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }

    
}
