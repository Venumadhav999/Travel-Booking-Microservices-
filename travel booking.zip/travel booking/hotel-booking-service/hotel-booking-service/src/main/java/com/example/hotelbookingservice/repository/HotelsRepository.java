package com.example.hotelbookingservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.hotelbookingservice.entity.Hotels;

import java.util.List;

@Repository
public interface HotelsRepository extends JpaRepository<Hotels, Integer> {

    List<Hotels> findByHotelNameContaining(String hotelName);
}
