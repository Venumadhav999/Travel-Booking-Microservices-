package com.example.hotelbookingservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.hotelbookingservice.entity.Bookings;
import com.example.hotelbookingservice.entity.Hotels;
import com.example.hotelbookingservice.entity.Rooms;
import com.example.hotelbookingservice.model.PaymentMode;
import com.example.hotelbookingservice.model.PaymentRequest;
import com.example.hotelbookingservice.response.ObjectResponse;
import com.example.hotelbookingservice.service.BookingService;
import com.example.hotelbookingservice.service.HotelService;
import com.example.hotelbookingservice.service.PaymentService;
import com.example.hotelbookingservice.service.RoomsService;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private BookingService bookingsService;

    @Autowired
    private HotelService hotelService;

    @Autowired
    private RoomsService roomsService;

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/add-booking")
    public ResponseEntity<ObjectResponse> addBooking(@RequestBody Bookings booking) {
        ObjectResponse resp = new ObjectResponse();
        try {
            bookingsService.saveBooking(booking);
            long paymentId = paymentService.processPayment(new PaymentRequest(
                    booking.getBkid(), 
                    booking.getAmount(), 
                    "Transaction123", 
                    PaymentMode.CREDIT_CARD));

            booking.setPaymentId(paymentId);
            resp.setResponseData(booking);
            resp.setStatusCode(HttpStatus.CREATED);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            logger.error("Error occurred while adding the booking", ex);
            resp.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
            resp.setMessage("Error occurred while adding the booking");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }

    @PostMapping("/add-hotel")
    public ResponseEntity<ObjectResponse> addHotel(@RequestBody Hotels hotel) {
        ObjectResponse resp = new ObjectResponse();
        try {
            hotelService.saveHotel(hotel);
            resp.setResponseData(hotel);
            resp.setStatusCode(HttpStatus.CREATED);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            logger.error("Error occurred while creating the hotel", ex);
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while creating the hotel");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }

    @PostMapping("/add-room")
    public ResponseEntity<ObjectResponse> addRoom(@RequestBody Rooms room) {
        ObjectResponse resp = new ObjectResponse();
        try {
            logger.debug("Received room data: {}", room);
            roomsService.saveRoom(room);
            resp.setResponseData(room);
            resp.setStatusCode(HttpStatus.CREATED);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            logger.error("Error occurred while creating the room", ex);
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while creating the room");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }
}
