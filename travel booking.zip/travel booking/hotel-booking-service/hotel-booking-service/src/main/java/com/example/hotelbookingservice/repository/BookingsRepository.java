package com.example.hotelbookingservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.hotelbookingservice.entity.Bookings;
import java.util.List;

@Repository
public interface BookingsRepository extends JpaRepository<Bookings, Integer> {

    List<Bookings> findByLastName(String lastName);
    List<Bookings> findByCheckinDate(String checkinDate);
}
