package com.example.hotelbookingservice.entity;


import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name = "hotels")
public class Hotels {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer htid;

    @Column(name = "hotel_name")
    private String hotelName;

    @Column(name = "hotel_country")
    private String hotelCountry;

    @Column(name = "hotel_city")
    private String hotelCity;

    @Column(name = "hotel_zipcode")
    private String hotelZipcode;

    @Column(name = "hotel_amenities")
    private String hotelAmenities;

    @Transient
    private List<Rooms> rooms;

    public Hotels() {
    }

    public Hotels(Integer htid, String hotelName, String hotelCountry, String hotelCity, String hotelZipcode,
            String hotelAmenities, List<Rooms> rooms) {
        this.htid = htid;
        this.hotelName = hotelName;
        this.hotelCountry = hotelCountry;
        this.hotelCity = hotelCity;
        this.hotelZipcode = hotelZipcode;
        this.hotelAmenities = hotelAmenities;
        this.rooms = rooms;
    } // Getters and Setters

    public Integer getHtid() {
        return htid;
    }

    public void setHtid(Integer htid) {
        this.htid = htid;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public String getHotelCountry() {
        return hotelCountry;
    }

    public void setHotelCountry(String hotelCountry) {
        this.hotelCountry = hotelCountry;
    }

    public String getHotelCity() {
        return hotelCity;
    }

    public void setHotelCity(String hotelCity) {
        this.hotelCity = hotelCity;
    }

    public String getHotelZipcode() {
        return hotelZipcode;
    }

    public void setHotelZipcode(String hotelZipcode) {
        this.hotelZipcode = hotelZipcode;
    }

    public String getHotelAmenities() {
        return hotelAmenities;
    }

    public void setHotelAmenities(String hotelAmenities) {
        this.hotelAmenities = hotelAmenities;
    }

    public List<Rooms> getRooms() {
        return rooms;
    }

    public void setRooms(List<Rooms> rooms) {
        this.rooms = rooms;
    }

    @Override
    public String toString() {
        return "Hotels [htid=" + htid + ", hotelName=" + hotelName + ", hotelCountry=" + hotelCountry + ", hotelCity="
                + hotelCity + ", hotelZipcode=" + hotelZipcode + ", hotelAmenities=" + hotelAmenities + ", rooms="
                + rooms + "]";
    }
    
}
