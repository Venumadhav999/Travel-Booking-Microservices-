package com.example.hotelbookingservice.service;

import com.example.hotelbookingservice.model.PaymentRequest;
import com.example.hotelbookingservice.model.PaymentResponse;

public interface PaymentService {

    long processPayment(PaymentRequest paymentRequest);

    PaymentResponse getPaymentDetailsByBookingId(Long bookingId);

}
