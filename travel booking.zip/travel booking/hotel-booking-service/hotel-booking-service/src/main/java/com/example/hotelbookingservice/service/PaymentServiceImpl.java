package com.example.hotelbookingservice.service;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotelbookingservice.entity.Payment;
import com.example.hotelbookingservice.model.PaymentMode;
import com.example.hotelbookingservice.model.PaymentRequest;
import com.example.hotelbookingservice.model.PaymentResponse;
import com.example.hotelbookingservice.repository.PaymentRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Override
    public long processPayment(PaymentRequest paymentRequest) {
        log.info("Recording Payment Details: {}", paymentRequest);
        try {
            Payment payment = Payment.builder()
                    .paymentDate(Instant.now())
                    .paymentMode(paymentRequest.getPaymentMode().name())
                    .paymentStatus("SUCCESS")
                    .bookingId(paymentRequest.getBookingId())
                    .amount(paymentRequest.getAmount())
                    .build();

            paymentRepository.save(payment);
            log.info("Payment Completed with Id: {}", payment.getPaymentId());
            return payment.getPaymentId();
        } catch (Exception ex) {
            log.error("Error occurred while processing the payment", ex);
            throw new RuntimeException("Payment processing failed");
        }
    }

    @Override
    public PaymentResponse getPaymentDetailsByBookingId(Long bookingId) {
        log.info("Getting payment details for the Booking Id: {}", bookingId);
        try {
            Payment payment = paymentRepository.findByBookingId(bookingId);
            if (payment == null) {
                throw new RuntimeException("Payment not found for Booking Id: " + bookingId);
            }
            return PaymentResponse.builder()
                    .paymentId(payment.getPaymentId())
                    .paymentMode(PaymentMode.valueOf(payment.getPaymentMode()))
                    .paymentDate(payment.getPaymentDate())
                    .bookingId(payment.getBookingId())
                    .status(payment.getPaymentStatus())
                    .amount(payment.getAmount())
                    .build();
        } catch (Exception ex) {
            log.error("Error occurred while retrieving payment details", ex);
            throw new RuntimeException("Failed to retrieve payment details");
        }
    }
}
