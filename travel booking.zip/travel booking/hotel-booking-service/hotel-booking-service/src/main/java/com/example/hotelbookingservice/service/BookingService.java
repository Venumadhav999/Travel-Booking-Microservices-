package com.example.hotelbookingservice.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.hotelbookingservice.entity.Bookings;
import com.example.hotelbookingservice.model.PaymentMode;
import com.example.hotelbookingservice.model.PaymentRequest;
import com.example.hotelbookingservice.repository.BookingsRepository;

@Service
public class BookingService {

    @Autowired
    private BookingsRepository repo;

    @Autowired
    private PaymentService paymentService; // Inject PaymentService here

    public void saveBooking(Bookings booking) {
        repo.save(booking);
        // Initiate payment process
        long paymentId = paymentService.processPayment(new PaymentRequest(booking.getBkid(), booking.getAmount(), "Transaction123", PaymentMode.CREDIT_CARD));
        // Associate payment ID with the booking
        booking.setPaymentId(paymentId);
    }

    public List<Bookings> findByLastName(String lastName) {
        return repo.findByLastName(lastName);
    }

    public List<Bookings> findByCheckinDate(String checkinDate) {
        return repo.findByCheckinDate(checkinDate);
    }
}
