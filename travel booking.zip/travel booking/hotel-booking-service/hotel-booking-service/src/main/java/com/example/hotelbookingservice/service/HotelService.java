package com.example.hotelbookingservice.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.hotelbookingservice.entity.Hotels;
import com.example.hotelbookingservice.entity.Rooms;
import com.example.hotelbookingservice.repository.HotelsRepository;
import com.example.hotelbookingservice.repository.RoomsRepository;

@Service
public class HotelService {

    @Autowired
    private HotelsRepository repo;

    @Autowired
    private RoomsRepository roomsRepo;

    public void saveHotel(Hotels hotel) {
        repo.save(hotel);
    }

    public List<Hotels> findByHotelName(String theHotelName) {
        return repo.findByHotelNameContaining(theHotelName);
    }

    public List<Hotels> findByHotelNameAndRooms(String theHotelName, String checkinDate, String checkoutDate) {
        List<Hotels> hotels = repo.findByHotelNameContaining(theHotelName);
        if (!hotels.isEmpty()) {
            for (Hotels hotel : hotels) {
                List<Rooms> availableRooms = roomsRepo.findByAvailableDateBetween(checkinDate, checkoutDate);
                hotel.setRooms(availableRooms);
            }
        }
        return hotels;
   
      }

}