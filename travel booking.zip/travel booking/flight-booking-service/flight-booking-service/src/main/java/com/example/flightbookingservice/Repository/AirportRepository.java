package com.example.flightbookingservice.Repository;


import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.flightbookingservice.Entity.Airport;

public interface AirportRepository extends JpaRepository<Airport, Long> {
    // You can add custom query methods here if needed
    List<Airport> findAll();
    
    
}

