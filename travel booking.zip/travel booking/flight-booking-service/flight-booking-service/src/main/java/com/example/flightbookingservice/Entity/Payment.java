package com.example.flightbookingservice.Entity;

import com.example.flightbookingservice.Model.PaymentMode;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long bookingId;  // Changed from String to Long
    private double amount;
    private String transactionId;
    private PaymentMode paymentMode;
    private String status;

    public Payment() {
    }

    public Payment(Long id, Long bookingId, double amount, String transactionId, PaymentMode paymentMode, String status) {
        this.id = id;
        this.bookingId = bookingId;
        this.amount = amount;
        this.transactionId = transactionId;
        this.paymentMode = paymentMode;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBookingId() {  // Changed from String to Long
        return bookingId;
    }

    public void setBookingId(Long bookingId) {  // Changed from String to Long
        this.bookingId = bookingId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Payment [id=" + id + ", bookingId=" + bookingId + ", amount=" + amount + ", transactionId="
                + transactionId + ", paymentMode=" + paymentMode + ", status=" + status + "]";
    }
}
