package com.example.flightbookingservice.Entity;

public enum ScheduleStatus {
    DELAYED, ON_TIME, CANCELLED
}
