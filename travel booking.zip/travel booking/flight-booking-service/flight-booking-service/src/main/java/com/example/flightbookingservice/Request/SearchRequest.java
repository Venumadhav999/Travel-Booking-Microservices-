package com.example.flightbookingservice.Request;

import java.sql.Date;

public class SearchRequest {
    
    private String startAirport;
    private String destinationAirport;
    private Date date;

    // Getters and setters
    public String getStartAirport() {
        return startAirport;
    }

    public void setStartAirport(String startAirport) {
        this.startAirport = startAirport;
    }

    public String getDestinationAirport() {
        return destinationAirport;
    }

    public void setDestinationAirport(String destinationAirport) {
        this.destinationAirport = destinationAirport;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
