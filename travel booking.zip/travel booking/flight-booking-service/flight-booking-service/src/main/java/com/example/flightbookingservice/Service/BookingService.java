package com.example.flightbookingservice.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.flightbookingservice.Entity.Airport;
import com.example.flightbookingservice.Entity.Booking;
import com.example.flightbookingservice.Entity.Flight;
import com.example.flightbookingservice.Entity.User;
import com.example.flightbookingservice.Model.BookingResponse;
import com.example.flightbookingservice.Repository.AirportRepository;
import com.example.flightbookingservice.Repository.BookingRepository;
import com.example.flightbookingservice.Repository.FlightRepository;
import com.example.flightbookingservice.Repository.UserRepository;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private FlightRepository flightRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AirportRepository airportRepository;

   
    

    public Booking saveBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    public BookingResponse getBookingResponse(Booking booking) {
        BookingResponse response = new BookingResponse();
        response.setId(booking.getId());
        
        // Retrieve and set Flight details
        Flight flight = flightRepository.findById(booking.getFlight().getId()).orElse(null);
        response.setFlight(flight);
        
        // Retrieve and set User details
        User user = userRepository.findById(booking.getUser().getId()).orElse(null);
        response.setUser(user);
        
        // Retrieve and set Start Airport details
        Airport startAirport = airportRepository.findById(booking.getStartAirport().getId()).orElse(null);
        response.setStartAirport(startAirport);
        
        // Retrieve and set Destination Airport details
        Airport destinationAirport = airportRepository.findById(booking.getDestinationAirport().getId()).orElse(null);
        response.setDestinationAirport(destinationAirport);
        
        // Set other details
        response.setDate(booking.getDate());
        response.setAmount(booking.getAmount());
        response.setPaymentId(booking.getPaymentId());

        return response;
    }
}
