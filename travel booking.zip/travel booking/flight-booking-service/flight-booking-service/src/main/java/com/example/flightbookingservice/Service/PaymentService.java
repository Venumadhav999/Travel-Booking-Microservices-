package com.example.flightbookingservice.Service;

import com.example.flightbookingservice.Request.PaymentRequest;
import com.example.flightbookingservice.Entity.Payment;
import com.example.flightbookingservice.Repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public long processPayment(PaymentRequest paymentRequest) {
        Payment payment = new Payment();
        payment.setBookingId(paymentRequest.getBookingId());
        payment.setAmount(paymentRequest.getAmount());
        payment.setTransactionId(paymentRequest.getTransactionId());
        payment.setPaymentMode(paymentRequest.getPaymentMode());
        payment.setStatus("SUCCESS"); // Simplified for example purposes

        Payment savedPayment = paymentRepository.save(payment);
        return savedPayment.getId();
    }
}
