package com.example.flightbookingservice.Controller;

import com.example.flightbookingservice.Entity.Booking;
import com.example.flightbookingservice.Model.ObjectResponse;
import com.example.flightbookingservice.Model.PaymentMode;
import com.example.flightbookingservice.Request.PaymentRequest;
import com.example.flightbookingservice.Service.BookingService;
import com.example.flightbookingservice.Service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/add-booking")
    public ResponseEntity<ObjectResponse> addBooking(@RequestBody Booking booking) {
        ObjectResponse resp = new ObjectResponse();
        try {
            Booking savedBooking = bookingService.saveBooking(booking);
            long paymentId = paymentService.processPayment(new PaymentRequest(
                    savedBooking.getId(),
                    savedBooking.getAmount(),
                    "Transaction123",
                    PaymentMode.CREDIT_CARD));

            savedBooking.setPaymentId(paymentId);
            resp.setResponseData(savedBooking);
            resp.setStatusCode(HttpStatus.CREATED);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            ex.printStackTrace();
            resp.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
            resp.setMessage("Error occurred while adding the booking");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }
}
