package com.example.flightbookingservice.Request;

import com.example.flightbookingservice.Model.PaymentMode;

public class PaymentRequest {
    private Long bookingId;  // Changed from String to Long
    private double amount;
    private String transactionId;
    private PaymentMode paymentMode;

    public PaymentRequest() {
    }

    public PaymentRequest(Long bookingId, double amount, String transactionId, PaymentMode paymentMode) {  // Updated constructor
        this.bookingId = bookingId;
        this.amount = amount;
        this.transactionId = transactionId;
        this.paymentMode = paymentMode;
    }

    public Long getBookingId() {  // Changed return type from String to Long
        return bookingId;
    }

    public void setBookingId(Long bookingId) {  // Changed parameter type from String to Long
        this.bookingId = bookingId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    @Override
    public String toString() {
        return "PaymentRequest [bookingId=" + bookingId + ", amount=" + amount + ", transactionId=" + transactionId
                + ", paymentMode=" + paymentMode + "]";
    }
}
