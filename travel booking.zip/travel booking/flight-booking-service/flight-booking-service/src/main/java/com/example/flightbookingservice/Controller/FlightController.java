package com.example.flightbookingservice.Controller;

import com.example.flightbookingservice.Entity.Airline;
import com.example.flightbookingservice.Entity.Airport;
import com.example.flightbookingservice.Entity.Flight;
import com.example.flightbookingservice.Entity.Schedule;
import com.example.flightbookingservice.Request.SearchRequest;
import com.example.flightbookingservice.Service.FlightService;
import com.example.flightbookingservice.Service.ScheduleService;
import com.example.flightbookingservice.Service.AirlineService;
import com.example.flightbookingservice.Service.AirportService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


@RestController
@RequestMapping("/admin/flights")
public class FlightController {

    private static final Logger LOGGER = LoggerFactory.getLogger(FlightController.class);
    
    @Autowired
    private final FlightService flightService;
    @Autowired
    private final AirlineService airlineService;
    @Autowired
    private final AirportService airportService;
    @Autowired
    private final ScheduleService scheduleService;

    
    public FlightController(FlightService flightService, AirlineService airlineService, AirportService airportService, ScheduleService scheduleService) {
        this.flightService = flightService;
        this.airlineService = airlineService;
        this.airportService = airportService;
        this.scheduleService = scheduleService;
    }

    @PostMapping("/add-airline")
    public ResponseEntity<Airline> addAirline(@RequestBody Airline airline) {
        LOGGER.info("Airline add: {}", airline);
        Airline addedAirline = airlineService.addAirline(airline);
        return ResponseEntity.ok(addedAirline);
    }

    @PostMapping("/airports")
    public ResponseEntity<Airport> addAirport(@RequestBody Airport airport) {
        Airport addedAirport = airportService.addAirport(airport);
        return new ResponseEntity<>(addedAirport, HttpStatus.CREATED);
    }

    @PostMapping("/add")
    public ResponseEntity<Flight> add(@RequestBody Flight flight) {
        LOGGER.info("Flight add: {}", flight);
        Flight addedFlight = flightService.addFlight(flight);
        return ResponseEntity.ok(addedFlight);
    }

    @GetMapping("/all")
    public List<Flight> findAll() {
        LOGGER.info("Flight find all");
        return flightService.getAllFlights();
    }

    @PostMapping("/add-schedule")
    public ResponseEntity<Schedule> addSchedule(@RequestBody Schedule schedule) {
        LOGGER.info("Schedule add: {}", schedule);
        Schedule addedSchedule = scheduleService.addSchedule(schedule);
        return ResponseEntity.ok(addedSchedule);
    }

    @PostMapping("/search")
    public ResponseEntity<List<Flight>> searchFlights(@RequestBody SearchRequest request) {
        LOGGER.info("Search flights with criteria: startAirport={}, destinationAirport={}, date={}",
                request.getStartAirport(), request.getDestinationAirport(), request.getDate());
        List<Flight> flights = flightService.searchFlights(request.getStartAirport(), request.getDestinationAirport(), request.getDate());
        return ResponseEntity.ok(flights);
    }
}
