package com.example.flightbookingservice.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.flightbookingservice.Entity.Airport;
import com.example.flightbookingservice.Repository.AirportRepository;

@Service
public class AirportService {

    @Autowired
    private AirportRepository AirportRepository;

    public List<Airport> getAllAirport() {
        return AirportRepository.findAll();
    }

    public Airport addAirport(Airport airport) {
        return AirportRepository.save(airport);
    }
    
}
