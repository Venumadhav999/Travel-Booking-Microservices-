package com.example.flightbookingservice.Service;

import com.example.flightbookingservice.Entity.Flight;
import com.example.flightbookingservice.Repository.FlightRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.sql.Date;
import java.util.List;

@Service
public class FlightService {
    private static final Logger LOGGER = LoggerFactory.getLogger(FlightService.class);

    private final FlightRepository flightRepository;

    public FlightService(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    public List<Flight> getAllFlights() {
        return flightRepository.findAll();
    }

    public Flight addFlight(Flight flight) {
        LOGGER.info("Adding flight: {}", flight);
        Flight savedFlight = null;
        try {
            savedFlight = flightRepository.save(flight);
            LOGGER.info("Flight saved: {}", savedFlight);
        } catch (Exception e) {
            LOGGER.error("Error saving flight: {}", e.getMessage());
        }
        return savedFlight;
    }
    

    public List<Flight> searchFlights(String startAirport, String destinationAirport, Date date){
        return flightRepository.findByStartAirportAndDestinationAirportAndDate(startAirport, destinationAirport, date); 
    }
}
