package com.example.flightbookingservice.Entity;

import java.sql.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Flight flight;

    @ManyToOne
    private User user;

    @ManyToOne
    private Airport startAirport;

    @ManyToOne
    private Airport destinationAirport;

    private Date date;
    private double amount;
    private Long paymentId; // Ensure this field exists

    public Booking() {
    }

    public Booking(Long id, Flight flight, User user, Airport startAirport, Airport destinationAirport, Date date, double amount, Long paymentId) {
        this.id = id;
        this.flight = flight;
        this.user = user;
        this.startAirport = startAirport;
        this.destinationAirport = destinationAirport;
        this.date = date;
        this.amount = amount;
        this.paymentId = paymentId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Airport getStartAirport() {
        return startAirport;
    }

    public void setStartAirport(Airport startAirport) {
        this.startAirport = startAirport;
    }

    public Airport getDestinationAirport() {
        return destinationAirport;
    }

    public void setDestinationAirport(Airport destinationAirport) {
        this.destinationAirport = destinationAirport;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    @Override
    public String toString() {
        return "Booking [id=" + id + ", flight=" + flight + ", user=" + user + ", startAirport=" + startAirport
                + ", destinationAirport=" + destinationAirport + ", date=" + date + ", amount=" + amount
                + ", paymentId=" + paymentId + "]";
    }
    

}