package com.example.flightbookingservice.Repository;

import com.example.flightbookingservice.Entity.Booking;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface BookingRepository extends CrudRepository<Booking, Long> {
    @Override
    <S extends Booking> S save(S booking);

    @Override
    Iterable<Booking> findAll(); 

    @Override
    void deleteById(Long id);

    // Other methods for CRUD operations
}
