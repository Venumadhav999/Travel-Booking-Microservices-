package com.example.flightbookingservice.Model;

import org.springframework.http.HttpStatus;

public class ObjectResponse {
    private HttpStatus statusCode;
    private String messageType;
    private String message;
    private Object responseData;
    
    public ObjectResponse() {
    }

    public ObjectResponse(HttpStatus statusCode, String messageType, String message, Object responseData) {
        this.statusCode = statusCode;
        this.messageType = messageType;
        this.message = message;
        this.responseData = responseData;
    }

    public HttpStatus getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(HttpStatus statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getResponseData() {
        return responseData;
    }

    public void setResponseData(Object responseData) {
        this.responseData = responseData;
    }

    @Override
    public String toString() {
        return "ObjectResponse [statusCode=" + statusCode + ", messageType=" + messageType + ", message=" + message
                + ", responseData=" + responseData + "]";
    }
}
