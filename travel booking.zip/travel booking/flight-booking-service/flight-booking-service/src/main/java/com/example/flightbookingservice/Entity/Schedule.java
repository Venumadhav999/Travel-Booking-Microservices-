package com.example.flightbookingservice.Entity;

import java.sql.Timestamp;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Schedule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "flight_id")
    private Flight flight;
    
    @ManyToOne
    @JoinColumn(name = "start_airport_id")
    private Airport startAirport;
    
    @ManyToOne
    @JoinColumn(name = "destination_airport_id")
    private Airport destinationAirport;
    
    private Timestamp startTime;
    private Timestamp endTime;
    private ScheduleStatus status;
    
    public Schedule() {
    }

    public Schedule(Long id, Flight flight, Airport startAirport, Airport destinationAirport, Timestamp startTime,
            Timestamp endTime, ScheduleStatus status) {
        this.id = id;
        this.flight = flight;
        this.startAirport = startAirport;
        this.destinationAirport = destinationAirport;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Airport getStartAirport() {
        return startAirport;
    }

    public void setStartAirport(Airport startAirport) {
        this.startAirport = startAirport;
    }

    public Airport getDestinationAirport() {
        return destinationAirport;
    }

    public void setDestinationAirport(Airport destinationAirport) {
        this.destinationAirport = destinationAirport;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public ScheduleStatus getStatus() {
        return status;
    }

    public void setStatus(ScheduleStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Schedule [id=" + id + ", flight=" + flight + ", startAirport=" + startAirport + ", destinationAirport="
                + destinationAirport + ", startTime=" + startTime + ", endTime=" + endTime + ", status=" + status + "]";
    }
}
