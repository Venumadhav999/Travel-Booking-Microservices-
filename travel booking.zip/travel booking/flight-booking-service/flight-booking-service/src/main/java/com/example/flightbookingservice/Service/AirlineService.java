package com.example.flightbookingservice.Service;

import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.flightbookingservice.Entity.Airline; 
import com.example.flightbookingservice.Repository.AirlineRepository;

@Service
public class AirlineService {

    @Autowired
    private AirlineRepository airlineRepository;

    public Airline addAirline(Airline airline) {
        // Save the airline entity to the database
        return airlineRepository.save(airline);
    }

    public List<Airline> getAllAirlines() {
        return airlineRepository.findAll();
    }

    
}
