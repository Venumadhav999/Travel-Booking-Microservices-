package com.example.flightbookingservice.Entity;

import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Airport {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String location;
    @OneToMany(mappedBy = "startAirport")
    private List<Schedule> departureSchedules = new ArrayList<>();

    @OneToMany(mappedBy = "destinationAirport")
    private List<Schedule> arrivalSchedules = new ArrayList<>();
    
    public Airport() {
    }

    public Airport(Long id, String name, String location, List<Schedule> departureSchedules,
            List<Schedule> arrivalSchedules) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.departureSchedules = departureSchedules;
        this.arrivalSchedules = arrivalSchedules;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public List<Schedule> getDepartureSchedules() {
        return departureSchedules;
    }

    public void setDepartureSchedules(List<Schedule> departureSchedules) {
        this.departureSchedules = departureSchedules;
    }

    public List<Schedule> getArrivalSchedules() {
        return arrivalSchedules;
    }

    public void setArrivalSchedules(List<Schedule> arrivalSchedules) {
        this.arrivalSchedules = arrivalSchedules;
    }

    @Override
    public String toString() {
        return "Airport [id=" + id + ", name=" + name + ", location=" + location + ", departureSchedules="
                + departureSchedules + ", arrivalSchedules=" + arrivalSchedules + "]";
    }

    
}