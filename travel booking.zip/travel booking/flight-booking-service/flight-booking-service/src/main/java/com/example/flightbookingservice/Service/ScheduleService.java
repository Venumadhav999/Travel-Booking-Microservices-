package com.example.flightbookingservice.Service;


import org.springframework.stereotype.Service;
import com.example.flightbookingservice.Entity.Schedule;
import com.example.flightbookingservice.Repository.ScheduleRepository;

@Service
public class ScheduleService {
    private final ScheduleRepository scheduleRepository;

    public ScheduleService(ScheduleRepository scheduleRepository) {
        this.scheduleRepository = scheduleRepository;
    }

    public Schedule addSchedule(Schedule schedule) {
        return scheduleRepository.save(schedule);
    }
    
}

