package com.example.flightbookingservice.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.flightbookingservice.Entity.Airline;
public interface AirlineRepository extends JpaRepository<Airline, Long> {
    
     List<Airline> findAll();

}

