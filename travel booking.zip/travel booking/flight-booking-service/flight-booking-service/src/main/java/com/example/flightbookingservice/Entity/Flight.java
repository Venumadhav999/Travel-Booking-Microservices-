package com.example.flightbookingservice.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.sql.Date;

@Entity
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "airline_id")
    @JsonBackReference
    private Airline airline;
    private int seatCapacity;
    private Date date;
    private String startAirport;
    private String destinationAirport;
    public Flight() {
    }
    public Flight(Long id, Airline airline, int seatCapacity, Date date, String startAirport,
            String destinationAirport) {
        this.id = id;
        this.airline = airline;
        this.seatCapacity = seatCapacity;
        this.date = date;
        this.startAirport = startAirport;
        this.destinationAirport = destinationAirport;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Airline getAirline() {
        return airline;
    }
    public void setAirline(Airline airline) {
        this.airline = airline;
    }
    public int getSeatCapacity() {
        return seatCapacity;
    }
    public void setSeatCapacity(int seatCapacity) {
        this.seatCapacity = seatCapacity;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public String getStartAirport() {
        return startAirport;
    }
    public void setStartAirport(String startAirport) {
        this.startAirport = startAirport;
    }
    public String getDestinationAirport() {
        return destinationAirport;
    }
    public void setDestinationAirport(String destinationAirport) {
        this.destinationAirport = destinationAirport;
    }
    @Override
    public String toString() {
        return "Flight [id=" + id + ", airline=" + airline + ", seatCapacity=" + seatCapacity + ", date=" + date
                + ", startAirport=" + startAirport + ", destinationAirport=" + destinationAirport + "]";
    }
}
