package com.example.carrentalbookingservice.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "reservations")
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "car_id")
    private Car car;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @Column(name = "reservation_date")
    private LocalDateTime reservationDate;

    @Column(name = "return_date")
    private LocalDateTime returnDate;

    @Column(name = "pick_up_location")
    private String pickUpLocation;

    @Column(name = "pick_up_date_time")
    private LocalDateTime pickUpDateTime;

    @Column(name = "drop_off_date_time")
    private LocalDateTime dropOffDateTime;

    @Column(name = "total_price")
    private Double totalPrice;

    public Reservation() {
    }

    public Reservation(Integer id, Car car, User user, LocalDateTime reservationDate, LocalDateTime returnDate,
            String pickUpLocation, LocalDateTime pickUpDateTime, LocalDateTime dropOffDateTime, Double totalPrice) {
        this.id = id;
        this.car = car;
        this.user = user;
        this.reservationDate = reservationDate;
        this.returnDate = returnDate;
        this.pickUpLocation = pickUpLocation;
        this.pickUpDateTime = pickUpDateTime;
        this.dropOffDateTime = dropOffDateTime;
        this.totalPrice = totalPrice;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LocalDateTime getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDateTime reservationDate) {
        this.reservationDate = reservationDate;
    }

    public LocalDateTime getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDateTime returnDate) {
        this.returnDate = returnDate;
    }

    public String getPickUpLocation() {
        return pickUpLocation;
    }

    public void setPickUpLocation(String pickUpLocation) {
        this.pickUpLocation = pickUpLocation;
    }

    public LocalDateTime getPickUpDateTime() {
        return pickUpDateTime;
    }

    public void setPickUpDateTime(LocalDateTime pickUpDateTime) {
        this.pickUpDateTime = pickUpDateTime;
    }

    public LocalDateTime getDropOffDateTime() {
        return dropOffDateTime;
    }

    public void setDropOffDateTime(LocalDateTime dropOffDateTime) {
        this.dropOffDateTime = dropOffDateTime;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    @Override
    public String toString() {
        return "Reservation [id=" + id + ", car=" + car + ", user=" + user + ", reservationDate=" + reservationDate
                + ", returnDate=" + returnDate + ", pickUpLocation=" + pickUpLocation + ", pickUpDateTime="
                + pickUpDateTime + ", dropOffDateTime=" + dropOffDateTime + ", totalPrice=" + totalPrice + "]";
    }
}
