package com.example.carrentalbookingservice.repository;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.example.carrentalbookingservice.entity.Car;

@Repository
public interface CarRepository extends JpaRepository<Car, Integer> {

     @Query("SELECT c FROM Car c WHERE c.availabilityStatus = true AND c.id NOT IN (SELECT r.car.id FROM Reservation r WHERE :pickUpDateTime BETWEEN r.pickUpDateTime AND r.dropOffDateTime OR :dropOffDateTime BETWEEN r.pickUpDateTime AND r.dropOffDateTime)")
    List<Car> findAvailableCars(@Param("pickUpDateTime") LocalDateTime pickUpDateTime, @Param("dropOffDateTime") LocalDateTime dropOffDateTime);

    List<Car> findByModel(String model);
}
