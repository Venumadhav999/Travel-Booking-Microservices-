package com.example.carrentalbookingservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.carrentalbookingservice.entity.Payment;
import com.example.carrentalbookingservice.response.ObjectResponse;
import com.example.carrentalbookingservice.service.PaymentService;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/process")
    public ResponseEntity<ObjectResponse> processPayment(@RequestBody Payment payment) {
        ObjectResponse resp = new ObjectResponse();
        try {
            Payment savedPayment = paymentService.save(payment);
            resp.setResponseData(savedPayment);
            resp.setStatusCode(HttpStatus.CREATED);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while processing the payment");
            resp.setMessageType("ERROR");
            ex.printStackTrace();
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }
}
