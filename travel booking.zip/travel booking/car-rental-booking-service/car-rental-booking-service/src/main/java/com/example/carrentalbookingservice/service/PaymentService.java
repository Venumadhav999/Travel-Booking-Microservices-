package com.example.carrentalbookingservice.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.carrentalbookingservice.entity.Payment;
import com.example.carrentalbookingservice.entity.Reservation;
import com.example.carrentalbookingservice.repository.PaymentRepository;

import java.time.LocalDateTime;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public Payment processPayment(Reservation reservation, Double amount) {
        Payment payment = new Payment(reservation, amount, LocalDateTime.now(), "SUCCESS");
        return paymentRepository.save(payment);
    }

    public Payment save(Payment payment) {
        return paymentRepository.save(payment);
    }
}
