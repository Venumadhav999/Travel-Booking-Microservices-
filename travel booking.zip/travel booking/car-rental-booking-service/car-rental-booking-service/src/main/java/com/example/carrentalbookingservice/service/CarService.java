package com.example.carrentalbookingservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.carrentalbookingservice.entity.Car;
import com.example.carrentalbookingservice.repository.CarRepository;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CarService {

    @Autowired
    private CarRepository carRepository;

    public List<Car> findAll() {
        return carRepository.findAll();
    }

    public Car save(Car car) {
        return carRepository.save(car);
    }

    public List<Car> findByModel(String model) {
        return carRepository.findByModel(model);
    }

    public void deleteById(Integer id) {
        carRepository.deleteById(id);
    }

    public List<Car> findAvailableCars(LocalDateTime pickUpDateTime, LocalDateTime dropOffDateTime) {
        return carRepository.findAvailableCars(pickUpDateTime, dropOffDateTime);
    }
}
