package com.example.carrentalbookingservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.carrentalbookingservice.entity.Reservation;
import com.example.carrentalbookingservice.repository.ReservationRepository;
import java.util.List;

@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private PaymentService paymentService;

    public List<Reservation> findAll() {
        return reservationRepository.findAll();
    }

    public Reservation save(Reservation reservation) {
        Reservation savedReservation = reservationRepository.save(reservation);
        // Process payment after reservation is saved
        paymentService.processPayment(savedReservation, savedReservation.getTotalPrice());
        return savedReservation;
    }

    public void deleteById(Integer id) {
        reservationRepository.deleteById(id);
    }
}
