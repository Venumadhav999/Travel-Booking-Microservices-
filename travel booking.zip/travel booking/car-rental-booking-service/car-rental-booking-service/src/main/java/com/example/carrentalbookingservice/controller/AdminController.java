package com.example.carrentalbookingservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.carrentalbookingservice.entity.Car;
import com.example.carrentalbookingservice.entity.Reservation;
import com.example.carrentalbookingservice.response.ObjectResponse;
import com.example.carrentalbookingservice.service.CarService;
import com.example.carrentalbookingservice.service.ReservationService;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private CarService carService;

    @Autowired
    private ReservationService reservationService;

    @PostMapping("/add-car")
    public ResponseEntity<ObjectResponse> addCar(@RequestBody Car car) {
        ObjectResponse resp = new ObjectResponse();
        try {
            logger.debug("Received car data: {}", car);
            carService.save(car);
            resp.setResponseData(car);
            resp.setStatusCode(HttpStatus.CREATED);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            logger.error("Error occurred while creating the car", ex);
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while creating the car");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }

    @PostMapping("/add-reservation")
    public ResponseEntity<ObjectResponse> addReservation(@RequestBody Reservation reservation) {
        ObjectResponse resp = new ObjectResponse();
        try {
            logger.debug("Received reservation data: {}", reservation);
            reservationService.save(reservation);
            resp.setResponseData(reservation);
            resp.setStatusCode(HttpStatus.CREATED);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            logger.error("Error occurred while creating the reservation", ex);
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while creating the reservation");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }

    @GetMapping("/all-cars")
    public ResponseEntity<ObjectResponse> getAllCars() {
        ObjectResponse resp = new ObjectResponse();
        try {
            logger.debug("Fetching all cars");
            resp.setResponseData(carService.findAll());
            resp.setStatusCode(HttpStatus.OK);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            logger.error("Error occurred while fetching cars", ex);
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while fetching cars");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }

    @GetMapping("/all-reservations")
    public ResponseEntity<ObjectResponse> getAllReservations() {
        ObjectResponse resp = new ObjectResponse();
        try {
            logger.debug("Fetching all reservations");
            resp.setResponseData(reservationService.findAll());
            resp.setStatusCode(HttpStatus.OK);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            logger.error("Error occurred while fetching reservations", ex);
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while fetching reservations");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }

    @GetMapping("/search-cars")
    public ResponseEntity<ObjectResponse> searchCars(@RequestParam String pickUpLocation, @RequestParam LocalDateTime pickUpDateTime, @RequestParam LocalDateTime dropOffDateTime) {
        ObjectResponse resp = new ObjectResponse();
        try {
            logger.debug("Searching cars for pickUpLocation: {}, pickUpDateTime: {}, dropOffDateTime: {}", pickUpLocation, pickUpDateTime, dropOffDateTime);
            List<Car> availableCars = carService.findAvailableCars(pickUpDateTime, dropOffDateTime);
            resp.setResponseData(availableCars);
            resp.setStatusCode(HttpStatus.OK);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            logger.error("Error occurred while searching for cars", ex);
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while searching for cars");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }

    @GetMapping("/findmymodel")
    public ResponseEntity<ObjectResponse> findMyModel(@RequestParam String model) {
        ObjectResponse resp = new ObjectResponse();
        try {
            logger.debug("Searching cars for model: {}", model);
            List<Car> cars = carService.findByModel(model);
            resp.setResponseData(cars);
            resp.setStatusCode(HttpStatus.OK);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            logger.error("Error occurred while searching for cars by model", ex);
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while searching for cars by model");
            resp.setMessageType("ERROR");
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }
}
