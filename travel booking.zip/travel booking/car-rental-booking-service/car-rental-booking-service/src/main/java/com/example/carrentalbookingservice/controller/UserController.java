package com.example.carrentalbookingservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.carrentalbookingservice.entity.User;
import com.example.carrentalbookingservice.response.ObjectResponse;
import com.example.carrentalbookingservice.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/Register/add-user")
    public ResponseEntity<ObjectResponse> addUser(@RequestBody User user) {
        ObjectResponse resp = new ObjectResponse();
        try {
            userService.save(user);
            resp.setResponseData(user);
            resp.setStatusCode(HttpStatus.CREATED);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while creating the user");
            resp.setMessageType("ERROR");
            ex.printStackTrace();
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }

    @GetMapping("/all-users")
    public ResponseEntity<ObjectResponse> getAllUsers() {
        ObjectResponse resp = new ObjectResponse();
        try {
            resp.setResponseData(userService.findAll());
            resp.setStatusCode(HttpStatus.OK);
            resp.setMessageType("SUCCESS");
        } catch (Exception ex) {
            resp.setStatusCode(HttpStatus.BAD_REQUEST);
            resp.setMessage("Error occurred while fetching users");
            resp.setMessageType("ERROR");
            ex.printStackTrace();
        }
        return new ResponseEntity<>(resp, resp.getStatusCode());
    }
}
