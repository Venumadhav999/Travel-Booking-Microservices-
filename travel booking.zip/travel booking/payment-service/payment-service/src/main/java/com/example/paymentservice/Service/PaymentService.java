package com.example.paymentservice.Service;

import com.example.paymentservice.Model.PaymentRequest;
import com.example.paymentservice.Model.PaymentResponse;

public interface PaymentService {

    long processPayment(PaymentRequest paymentRequest);

    PaymentResponse getPaymentDetailsByBookingId(Long bookingId);

}
