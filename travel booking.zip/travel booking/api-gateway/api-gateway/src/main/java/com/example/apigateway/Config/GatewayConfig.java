package com.example.apigateway.Config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("flight-booking-service", r -> r.path("/users/**")
                        .uri("lb://flight-booking-service"))
                .route("flight-booking-service", r -> r.path("/admin/flights/**")
                        .uri("lb://flight-booking-service"))
                .route("flight-booking-service", r -> r.path("/bookings/**")
                        .uri("lb://flight-booking-service"))
                .route("hotel-booking-service", r -> r.path("/admin/**")
                        .uri("lb://hotel-booking-service"))
                .route("hotel-booking-service", r -> r.path("/search/**")
                        .uri("lb://hotel-booking-service"))
                .route("hotel-booking-service", r -> r.path("/v1/api/payments/**")
                        .uri("lb://hotel-booking-service"))
                .route("car-rental-booking-service", r -> r.path("/admin/**")
                        .uri("lb://car-rental-booking-service"))
                .route("car-rental-booking-service", r -> r.path("/user/**")
                        .uri("lb://car-rental-booking-service"))
                .route("car-rental-booking-service", r -> r.path("/payment/**")
                        .uri("lb://car-rental-booking-service"))        
                .route("payment-service", r -> r.path("/v1/api/payments/**")
                        .uri("lb://payment-service"))
                .build();
    }
}

    

